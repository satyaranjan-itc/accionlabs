/******
Author:Satyaranjan Mishra
Here, I have created the angular module and the controller to fetch data.
I have written the service here inside the controller as this is simple app and the the data need not be shared across controllers.
The best practice is always we should keep the controller as light as possible and write the server call in services
*/
var app = angular.module('myApp', ['angularUtils.directives.dirPagination']);

app.controller('storyCtrl', function($scope, $http){
	$scope.userStories = []; //declare an empty array
    $http.get("http://jsonplaceholder.typicode.com/posts").then(
	function(response){
	        $scope.userStories = response.data;//http request to fetch data into $scope.userStories
    },
	function(error) {
        // Handle error here
    });
	$scope.sort = function(keyname){
         $scope.sortKey = keyname;   //set the sortKey to the param passed
         $scope.reverse = !$scope.reverse; //if true make it false and vice versa
     }

})